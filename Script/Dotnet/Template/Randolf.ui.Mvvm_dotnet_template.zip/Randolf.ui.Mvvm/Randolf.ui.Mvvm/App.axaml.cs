using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Randolf.ui.Mvvm.Library.ViewModels;
using Randolf.ui.Mvvm.Views;
using ReactiveUI;
using Splat;
using System;

namespace Randolf.ui.Mvvm
{
    public class App : Application, IEnableLogger
    {
        public override void Initialize()
        {
            AvaloniaXamlLoader.Load(this);
            this.Log().Debug("Hello World!");
        }

        public override void OnFrameworkInitializationCompleted()
        {
            if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
            {
                var mainWindow = Locator.Current.GetService<MainWindow>()
                                 ?? throw new Exception("Exception while create MainWindow");
                mainWindow.DataContext = Locator.Current.GetService<MainWindowViewModel>()
                                 ?? throw new Exception("Exception while create MainWindowViewModel");
                desktop.MainWindow = mainWindow;
            }

            base.OnFrameworkInitializationCompleted();
        }
    }
}