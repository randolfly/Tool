using Avalonia;
using Avalonia.ReactiveUI;
using Randolf.ui.Mvvm.Library.ViewModels;
using ReactiveUI;
using Splat;

namespace Randolf.ui.Mvvm.Views
{
    [SingleInstanceView]
    public partial class MainWindow : ReactiveWindow<MainWindowViewModel>, IEnableLogger
    {
        public MainWindow()
        {
            InitializeComponent();
#if DEBUG
            this.AttachDevTools();
#endif
        }

    }
}