﻿using ReactiveUI;
using Splat;

namespace Randolf.ui.Mvvm.Library.ViewModels;

public class ViewModelBase : ReactiveObject, IEnableLogger
{
}