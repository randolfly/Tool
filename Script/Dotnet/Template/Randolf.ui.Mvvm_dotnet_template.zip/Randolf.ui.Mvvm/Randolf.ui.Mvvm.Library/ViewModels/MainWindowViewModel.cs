﻿namespace Randolf.ui.Mvvm.Library.ViewModels;

public class MainWindowViewModel : ViewModelBase
{
    public string Greetings => "Hello Avalonia!";
}